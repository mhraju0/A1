var indexValue = 1;
Showimg(indexValue);

function btm_slide(e) {
  Showimg(indexValue = e);
}

function side_slide(e) {
  Showimg(indexValue += e);
}

function Showimg(e) {
  var i;
  const img = document.querySelectorAll(".img img");
  const slider = document.querySelectorAll(".slides span");

  if (e > img.length) { indexValue = 1 }
  if (e < 1) { indexValue = img.length }
  for (i = 0; i < img.length; i++) { img[i].style.display = "none"; }
  for (i = 0; i < slider.length; i++) { slider[i].style.background = "transparent"; }

  img[indexValue - 1].style.display = "block";
  slider[indexValue - 1].style.background = "white";

}
function changeStyle() {
  var element = document.getElementById("myElement");
  element.style.opacity = "1";
}
function close() {
  var element = document.getElementById("Element");
  element.style.opacity = "0";
}
